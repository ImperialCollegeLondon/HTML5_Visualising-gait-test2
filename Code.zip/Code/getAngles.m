function [ angleX, angleY, angleZ ] = getAngles( gyro, FF, fs, L )

angleX_temp = 0;
angleY_temp = 0;
angleZ_temp = 0;
angleX = zeros(L,1);
angleY = zeros(L,1);
angleZ = zeros(L,1);
for i=1:L
    if FF(i) == 0
        angleX_temp = angleX_temp+gyro(i,1)/fs;
        angleX(i) = angleX_temp;
        angleY_temp = angleY_temp+gyro(i,2)/fs;
        angleY(i) = angleY_temp;
        angleZ_temp = angleZ_temp+gyro(i,3)/fs;
        angleZ(i) = angleZ_temp;
    else
        angleX_temp = 0;
        angleX(i) = angleX_temp;
        angleY_temp = 0;
        angleY(i) = angleY_temp;
        angleZ_temp = 0;
        angleZ(i) = angleZ_temp;
    end
end

end

