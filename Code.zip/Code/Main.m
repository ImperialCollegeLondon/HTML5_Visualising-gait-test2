%%%%%%%%%%%%%%%%%% HS/TO/left turn/right turn extraction %%%%%%%%%%%%%%%%%%

%clc;clear;

% Load reference gait cycle and gait data
load('standard.mat');
load('gait_data_subject_43.mat');
Left =  GA2160434x10mLeftFoot; 
Right = GA2160434x10mRightFoot;
accLeft = [Left.accXg1024Hz,Left.accYg1024Hz,Left.accZg1024Hz];
accRight = [Right.accXg1024Hz,Right.accYg1024Hz,Right.accZg1024Hz];
gyroLeft = [Left.gyroXdegs1024Hz,Left.gyroYdegs1024Hz,Left.gyroZdegs1024Hz];
gyroRight = [Right.gyroXdegs1024Hz,Right.gyroYdegs1024Hz,Right.gyroZdegs1024Hz];
[L,~] = size(accLeft);

%% DTW-based Gait Cycle Detection - Right Ankle

% Starting position
START = 60;
fs = 1024/10;
fc = [0.5 12];

% Smoothing signals
gyroRight_filtered = bandPassFilter(gyroRight(1:end,3), fs ,fc );

% Gait cycle detection
CYC_Right = gaitCYC(gyroRight_filtered,standard,60,59,5,START);

% Removing incorrect gait cycles
threshold = 80;q = 1;
while(q==1)
    for i=2:length(CYC_Right)-1
        q = 0;
        if CYC_Right(i)-CYC_Right(i-1)<threshold && CYC_Right(i+1)-CYC_Right(i)<threshold
            CYC_Right(i) = [];q = 1;break;
        end
    end
end

figure;subplot(5,2,1);
plot(gyroRight_filtered);hold on;vline(CYC_Right);
title('Right GyroZ (smoothed)');

%% TO HS Timing Extraction - Right Ankle

% Set minimum peak height for HS and TO peaks
minPeakHeight = 100;

% Find TO and HS in each gait cycle
[pks_right,locs_pks_right] = getTOHS(gyroRight(:,3),CYC_Right,minPeakHeight);

subplot(5,2,3);
plot(gyroRight(:,3));hold on;vline(CYC_Right);
plot(locs_pks_right(1,:),pks_right(1,:),'^');
plot(locs_pks_right(2,:),pks_right(2,:),'o');
title('Right TO and HS');

%% DTW-based Gait Cycle Detection - Left Ankle

% Starting position
START = 60;
fs = 1024/10;
fc = [0.5 12];

% Smoothing signals
gyroLeft_filtered = bandPassFilter(gyroLeft(1:end,3), fs ,fc );

% Gait cycle detection
CYC_Left = gaitCYC(gyroLeft_filtered,standard,60,59,5,START);

% Removing incorrect gait cycles
threshold = 80;q = 1;
while(q==1)
    for i=2:length(CYC_Left)-1
        q = 0;
        if CYC_Left(i)-CYC_Left(i-1)<threshold && CYC_Left(i+1)-CYC_Left(i)<threshold
            CYC_Left(i) = [];q = 1;break;
        end
    end
end

subplot(5,2,2);
plot(gyroLeft_filtered);hold on;vline(CYC_Left);
title('Left GyroZ (smoothed)');

%% TO HS Timing Extraction - Left Ankle

% Set minimum peak height for HS and TO peaks
minPeakHeight = 100;

% Find TO and HS in each gait cycle
[pks_left,locs_pks_left] = getTOHS(gyroLeft(:,3),CYC_Left,minPeakHeight);

subplot(5,2,4);
plot(gyroLeft(:,3));hold on;vline(CYC_Left);
plot(locs_pks_left(1,:),pks_left(1,:),'^');
plot(locs_pks_left(2,:),pks_left(2,:),'o');
title('Left TO and HS');


%% Right/Left Turns Detection

energyLeft = zeros(L,1);turnLeft = zeros(L,1);turnRight = zeros(L,1);
TH = 70;
for i=1:length(CYC_Left)-1
    tempX = mean(gyroLeft(1+CYC_Left(i):1+CYC_Left(i+1),1));
    tempY = mean(gyroLeft(1+CYC_Left(i):1+CYC_Left(i+1),2));
    energyLeft(1+CYC_Left(i):1+CYC_Left(i+1)) = tempX-tempY;
    if tempX-tempY>TH
        turnLeft(1+CYC_Left(i):1+CYC_Left(i+1)) = 1;
    end
    if tempX-tempY<-TH
        turnRight(1+CYC_Left(i):1+CYC_Left(i+1)) = 1;
    end
end
subplot(5,2,5);hold on;
area(energyLeft,'FaceColor','b','FaceAlpha',0.5,'EdgeColor','b','EdgeAlpha',0.5);
plot(gyroRight(:,3));
area(400*turnRight,'FaceColor','r','FaceAlpha',0.5,'EdgeColor','r','EdgeAlpha',0.5);
title('Right Turns');

subplot(5,2,6);hold on;
area(energyLeft,'FaceColor','b','FaceAlpha',0.5,'EdgeColor','b','EdgeAlpha',0.5);
plot(gyroLeft(:,3));
area(400*turnLeft,'FaceColor','g','FaceAlpha',0.5,'EdgeColor','g','EdgeAlpha',0.5);
title('Left Turns');

%% Sliding Window-Based Foot-Flat period detection

w1 = 10;w2 = 3;
[ FF_Right ] = getFF(gyroRight(:,3).',CYC_Right,locs_pks_right,w1,w2,L);
[ FF_Left ] = getFF(gyroLeft(:,3).',CYC_Left,locs_pks_left,w1,w2,L);

%% Cumulative Integration for Angles for Each Gait Cycle (Reset at each FF)

fs =102.4;
[angleX_Right,angleY_Right,angleZ_Right] = getAngles(gyroRight,FF_Right,fs,L);
[angleX_Left,angleY_Left,angleZ_Left] = getAngles(gyroLeft,FF_Left,fs,L);

subplot(5,2,7);hold on;
plot(angleZ_Right);
plot(FF_Right*40);
title('Right AngleZ and Foot-Flat');

subplot(5,2,8);hold on;
plot(angleZ_Left);
plot(FF_Left*40);
title('Left AngleZ and Foot-Flat');

%% Double Cumulative Integration for Displacement (Reset at each FF)

gamma = 30;
[dispX_Right,dispY_Right,dispZ_Right] = getDisplacement(accRight,angleZ_Right,FF_Right,gamma,L);
[dispX_Left,dispY_Left,dispZ_Left] = getDisplacement(accLeft,angleZ_Left,FF_Left,gamma,L);

subplot(5,2,9);
hold on;
plot(dispX_Right)
plot(dispY_Right)
title('Right Walking/Vertical Displacement (m)');
subplot(5,2,10);
hold on;
plot(dispX_Left)
plot(dispY_Left)
title('Left Walking/Vertical Displacement (m)');

%% Graphical Enhancement

figHandles=get(0,'Children');
set(findall(figHandles,'type','text'),'fontSize',13,'fontWeight','bold');
set(findall(figHandles,'type','line'),'LineWidth',2);
set(findall(figHandles,'type','legend'),'fontSize',13,'fontWeight','bold');
