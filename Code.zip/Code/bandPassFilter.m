function [ dataOut ] = bandPassFilter( Accel, fs ,fc )
% Bandpass
[b,a] = cheby2(3,40,fc/fs,'bandpass');
%freqz(b,a)
dataIn = Accel;
dataOut = filter(b,a,dataIn);
end