function [ CYC ] = gaitCYC( ACC, stride, mid, hr, th, START )

str = stride/(max(stride)-min(stride));
cnt1 = 0;DIST = [];STR_temp = [];

while (1)
    if START+mid+hr > length(ACC)
       break 
    end
    cnt1 = cnt1+1;
    cnt = 0;dist=[];
    if cnt1 <= th
        str_now = str;
    else
        str_temp = sum(STR_temp(cnt1-th:cnt1-1,:));
        str_now = str_temp/(max(str_temp)-min(str_temp));
    end
    
    for w=mid-hr:mid+hr
        cnt = cnt+1;
        acc = ACC(START:START+w);
        acc = acc/(max(acc)-min(acc));
        dist(cnt) = dtw(str_now,acc);
    end
    [~,I]=sort(dist,'ascend');
    DIST = [DIST,dist(I(1))];
    MIN = mid-hr+I(1);
    CYC(cnt1) = START+MIN;
    
    if cnt1==1
        start = 1;
    else
        start = CYC(cnt1-1);
    end
    STR_temp(cnt1,:) = interpWithCorrection(ACC(start:CYC(cnt1)),100);
    START = START+MIN;
end
end

