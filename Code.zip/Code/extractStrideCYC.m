function [ stride ] = extractStrideCYC( Accel, cycles )
    
m = length(cycles)-1;
stride=zeros(1,100);

for i=1:m
    acc = Accel(cycles(i):cycles(i+1));
    l = length(acc);
    temp = interp1(1:1:l,acc,1:l/100:l,'linear');
    if length(temp)<96
        temp(96) = temp(95);
    end
    if length(temp)<97
        temp(97) = temp(96);
    end
    if length(temp)<97
        temp(97) = temp(96);
    end
    if length(temp)<98
        temp(98) = temp(97);
    end
    if length(temp)<99
        temp(99) = temp(98);
    end
    if length(temp)<100
        temp(100) = temp(99);
    end
    stride = stride+temp;
end

stride = stride/m;

end
