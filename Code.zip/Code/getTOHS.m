function [ pks, locs_pks ] = getTOHS( Accel, CYC, minPeakHeight )

cycles = CYC;
stride = extractStrideCYC( -Accel, cycles );
Len = 100;

[~,locs_SD] = findpeaks(stride,'MinPeakHeight',minPeakHeight);

m = length(cycles) - 1;
for i=1:m
    len = cycles(i+1) - cycles(i);
    acc = -Accel(cycles(i):cycles(i+1));
    [pk,locs_pk] = findpeaks(acc,'MinPeakHeight',1,'MinPeakWidth',1);

    lSD = floor((locs_SD/Len)*len);

    for j=1:length(lSD)
        [~,Ip] = min(((locs_pk-lSD(j)).^2).^.5);
        locs_pks(j,i) = cycles(i)+locs_pk(Ip)-1;
        pks(j,i) = -pk(Ip);
    end
end
end