function [ dispX, dispY, dispZ ] = getDisplacement( acc, angleZ, FF, gamma, L )

dispX_temp = 0;
dispY_temp = 0;
dispZ_temp = 0;
dispX = zeros(L,1);
dispY = zeros(L,1);
dispZ = zeros(L,1);
vX_temp = 0;vY_temp = 0;vZ_temp = 0;
for i=1:L
    if FF(i) == 0
        accX = acc(i,1)*cosd(angleZ(i))+acc(i,2)*cosd(90-angleZ(i));
        accX = accX*cosd(gamma);
        accY = -acc(i,1)*sind(angleZ(i))-acc(i,2)*sind(90-angleZ(i))-1;
        accZ = acc(i,3);

        vX_temp = vX_temp+accX*9.8/102.4;
        dispX_temp = dispX_temp+vX_temp/102.4;
        dispX(i) = dispX_temp;
        vY_temp = vY_temp+accY*9.8/102.4;
        dispY_temp = dispY_temp+vY_temp/102.4;
        dispY(i) = dispY_temp;
        vZ_temp = vZ_temp+accZ*9.8/102.4;
        dispZ_temp = dispZ_temp+vZ_temp/102.4;
        dispZ(i) = dispZ_temp;
    else
        vX_temp = 0;vY_temp = 0;vZ_temp = 0;
        dispX_temp = 0;
        dispX(i) = dispX_temp;
        dispY_temp = 0;
        dispY(i) = dispY_temp;
        dispZ_temp = 0;
        dispZ(i) = dispZ_temp;
    end
    
end

end

