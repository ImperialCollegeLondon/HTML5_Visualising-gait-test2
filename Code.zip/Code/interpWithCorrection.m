function [ temp ] = interpWithCorrection( acc, Len )

Len = Len+1;
l = length(acc);
temp=interp1(1:1:l,acc,1:l/Len:l,'linear');
if length(temp)<96
    temp(96)=temp(95);
end
if length(temp)<97
    temp(97)=temp(96);
end
if length(temp)<98
    temp(98)=temp(97);
end
if length(temp)<99
    temp(99)=temp(98);
end
if length(temp)<100
    temp(100)=temp(99);
end
if length(temp)>100
    temp = temp(1:Len-1);
end

end

