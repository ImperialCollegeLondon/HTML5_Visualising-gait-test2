function [ FF ] = getFF( gyro, CYC, locs_pks, w1, w2, L )

FF = ones(L,1);
FF1 = [];FF2 = [];
for i=1:length(CYC)-1
    ff1 = 0;ff2 = 0;
    Lc = locs_pks(1,i)-CYC(i);
    
    for j = w1+1:Lc-w1
        W = j-w1:j+w1;
        data_temp = (gyro(CYC(i)+W))./100;
        sum1 = sum(data_temp(1:w1));
        sum2 = sum(data_temp(w1+2:end));
        if sum1/10 > sum2
            ff1 = CYC(i)+j;
            FF1 = [FF1,CYC(i)+j];
            break;
            FF1 = CYC_Right(i)+Lc-w1;
        end
    end
    
    Lc = CYC(i+1)-locs_pks(2,i);
    for j = w2+1:Lc-w2
        W = j-w2:j+w2;
        data_temp = (gyro(locs_pks(2,i)+W))./100;
        sum1 = sum(data_temp(1:w2));
        sum2 = sum(data_temp(w2+2:end));
        if sum1 < sum2/5
            ff2 = locs_pks(2,i)+j;
            FF2 = [FF2,locs_pks(2,i)+j];
            break;
        end
    end
    
    if ff1 ~= 0 && ff2 ~= 0
        FF(ff1:ff2) = 0;
    end
    
end

end

