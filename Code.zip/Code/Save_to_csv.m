% Save to csv file

offset = 0;
HS_left = zeros(L,1);
HS_right = zeros(L,1);
TO_left = zeros(L,1);
TO_right = zeros(L,1);
for i=1:length(locs_pks_left(1,:))
    HS_left(locs_pks_left(1,i)+offset) = 1;
    TO_left(locs_pks_left(2,i)+offset) = 1;
end
for i=1:length(locs_pks_right(1,:))
    HS_right(locs_pks_right(1,i)+offset) = 1;
    TO_right(locs_pks_right(2,i)+offset) = 1;
end
Left.HS_left = HS_left;
Left.TO_left = TO_left;
Right.HS_right = HS_right;
Right.TO_right = TO_right;
Left.turnLeft = turnLeft;
Left.turnRight = turnRight;
Right.turnLeft = turnLeft;
Right.turnRight = turnRight;
Left.FF = FF_Left;
Right.FF = FF_Right;
Left.angleX_Left = angleX_Left;
Left.angleY_Left = angleY_Left;
Left.angleZ_Left = angleZ_Left;
Right.angleX_Right = angleX_Right;
Right.angleY_Right = angleY_Right;
Right.angleZ_Right = angleZ_Right;
Left.dispX_Left = dispX_Left;
Left.dispY_Left = dispY_Left;
Left.dispZ_Left = dispZ_Left;
Right.dispX_Right = dispX_Right;
Right.dispY_Right = dispY_Right;
Right.dispZ_Right = dispZ_Right;

%%
writetable(Left,   'data_left_subject_3.csv');
writetable(Right, 'data_right_subject_3.csv');


